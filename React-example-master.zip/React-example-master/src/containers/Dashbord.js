import React from 'react';
const Item = () => (
    <div>
        Dashbord
    </div>
);
export default Item
